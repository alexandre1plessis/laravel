<li class="header">Design patterns</li>
<li>
    <a href="/singleton"><i class="fa fa-book"></i> <span>Singleton</span></a>
</li>
